#!/bin/bash
echo hello from bowerbird
