#!/bin/bash
uname -a && uptime
